# similar to firefox
#background = "#eeeeee"
#activebackground = "#fcfcfc"
background = "#f4f4f4"
activebackground = "#e0e0e0"

# experimental color
#background = "#eeffff"
#activebackground = "#aaffff"
